import cv2
import numpy as np
import random 

x = 12
y = 500

t_start = -1
t_end = 8

colour_s = 0
colour_e = 255

height = 512
width = 512

for num in range(0 , 1500):
    img1 = np.zeros([height, width, 3], dtype=np.uint8)
        
    rectangle = cv2.rectangle(img1,
                       (random.randint(50, 150),random.randint(12, 150)),
                           (random.randint(151, 200), random.randint(151, 200)),
                           (random.randint(colour_s, colour_e),
                            random.randint(colour_s, colour_e),
                            random.randint(colour_s, colour_e)),
                           random.randint(t_start, t_end))

    cv2.imwrite(r'/home/yash/Desktop/KhashCapitals/Interview-master/Images/rectangle/rect_{}.jpg'.format(num), rectangle)
