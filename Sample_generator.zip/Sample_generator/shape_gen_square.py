import cv2
import numpy as np
import random 

x = 12
y = 500

t_start = -1
t_end = 8

colour_s = 0
colour_e = 255

height = 512
width = 512

for num in range(0 , 1500):
    # img1 = np.ones((512, 512, 3))
    img1 = np.zeros([height, width, 3], dtype=np.uint8)

    X = random.randint(x, y)
    Y = random.randint(x, y)

    rectangle = cv2.rectangle(img1,
                       (X,Y),
                           (Y, X),
                           (random.randint(colour_s, colour_e),
                            random.randint(colour_s, colour_e),
                            random.randint(colour_s, colour_e)),
                           random.randint(t_start, t_end))

    cv2.imwrite(r'/home/yash/Desktop/KhashCapitals/Interview-master/Images/Sqaure/Sqaure_{}.jpg'.format(num), rectangle)

# cv2.waitKey(0)
# cv2.destroyWindow('Yash')
