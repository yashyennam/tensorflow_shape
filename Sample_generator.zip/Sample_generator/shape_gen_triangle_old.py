import cv2
import numpy as np
import random 

x = 12
y = 500

t_start = -1
t_end = 8

colour_s = 0
colour_e = 255

height = 512
width = 512

for num in range(0 , (4000-709)):
    # img1 = np.ones((512, 512, 3))
    img = np.zeros([height, width, 3], dtype=np.uint8)
    
    p1 = (random.randint(x, y), random.randint(x, y))
    p2 = (random.randint(x, y), random.randint(x, y))
    p3 = (random.randint(x, y), random.randint(x, y))

    cv2.line(img, p1, p2, (255, 0, 0), 3)
    cv2.line(img, p2, p3, (255, 0, 0), 3) 
    cv2.line(img, p1, p3, (255, 0, 0), 3)

    centroid = ((p1[0]+p2[0]+p3[0])//3, (p1[1]+p2[1]+p3[1])//3)

    rectangle = cv2.circle(img, centroid, 4, (0, 255, 0))
    
    cv2.imwrite(r'/home/yash/Desktop/KhashCapitals/Interview-master/Images/triangle/triangle_{}.jpg'.format(num), rectangle)

# cv2.waitKey(0)
# cv2.destroyWindow('Yash')
