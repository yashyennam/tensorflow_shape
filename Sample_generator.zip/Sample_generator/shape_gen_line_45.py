import numpy as np 
import cv2
import random

degree = 90
low = degree - 5
high = degree + 5

for num in range(10,4000):
    img = cv2.imread(r'/home/yash/Desktop/KhashCapitals/Interview-master/Images/line_0/line_{0}.jpg'.format(num),0)
    
    rows,cols = img.shape

    matrix=cv2.getRotationMatrix2D((rows/2, cols/2), random.randint(low, high), 1)
    new_img = cv2.warpAffine(img, matrix, (cols, rows))

    cv2.imwrite(r'/home/yash/Desktop/KhashCapitals/Interview-master/Images/line_60/line_{0}.jpg'.format((num-10)), new_img)
