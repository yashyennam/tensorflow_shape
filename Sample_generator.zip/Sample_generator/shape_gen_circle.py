import cv2
import numpy as np
import random 

x = (512/2) - 20
y = (512/2) + 20

t_start = -1
t_end = 8

colour_s = 0
colour_e = 255

height = 512
width = 512


for num in range(0 , 1500):
    img = np.zeros([512, 512, 3], dtype=np.uint8)

    circle = cv2.circle(img,
                        (random.randint(x, y), random.randint(x, y)),
                        random.randint(25,150),
                        (random.randint(colour_s, colour_e), random.randint(colour_s, colour_e), random.randint(colour_s, colour_e)),
                        -1)

    cv2.imwrite(r'/home/yash/Desktop/KhashCapitals/Interview-master/Images/circle/circle_{}.jpg'.format(num), circle)

