import cv2
import numpy as np
import random

height = 512
width = 512


for num in range(0, 1500):
    image = np.zeros([height, width, 3], dtype=np.uint8)

    ##pt1 = (150, 100)
    ##pt2 = (100, 200)
    ##pt3 = (200, 200)

    x = 12
    y = 500

    pt1 = (random.randint(50, 200), random.randint(50, 200))
    pt2 = (random.randint(350, 450), random.randint(50, 200))
    pt3 = (random.randint(100, 250), random.randint(250, 420))

    cv2.circle(image, pt1, 2, (0,0,255), -1)
    cv2.circle(image, pt2, 2, (0,0,255), -1)
    cv2.circle(image, pt3, 2, (0,0,255), -1)

    triangle_cnt = np.array( [pt1, pt2, pt3] )

    triangle = cv2.drawContours(image, [triangle_cnt], 0, (0,255,0), random.randint(2, 6))

    cv2.imwrite(r'/home/yash/Desktop/KhashCapitals/Interview-master/Images/triangle/triangle_{}.jpg'.format(num), triangle)
    
