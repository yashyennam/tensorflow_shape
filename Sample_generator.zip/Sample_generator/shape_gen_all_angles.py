import numpy as np
import cv2
import random
import os

x = 12
y = 500

t_start = 2
t_end = 8

colour_s = 0
colour_e = 255

height = 512
width = 512

lst_angle = []
int_angle = []

for x in range(0, 180, 10):
    int_angle.append((x, x+9))
    lst_angle.append("{}-{}".format(x, x+9))

print(lst_angle)

for i_angle, angle in zip(int_angle, lst_angle):
    low = i_angle[0]
    high = i_angle[1]
    # Directory
    directory = "line_{}".format(angle)
    parent_dir = r"/home/yash/Desktop/KhashCapitals/Interview-master/Images"

    # Path
    path = os.path.join(parent_dir, directory)
    print (path)

    os.mkdir(path)

    for num in range(10,800):

        img = cv2.imread(r'/home/yash/Desktop/KhashCapitals/Interview-master/Images/line_0/line_{}.jpg'.format(num),0)

        rows,cols = img.shape

        matrix=cv2.getRotationMatrix2D((rows/2, cols/2), random.randint(low, high), 1)
        new_img = cv2.warpAffine(img, matrix, (cols, rows))

        cv2.imwrite(r'{0}/line_{1}.jpg'.format(path, num), new_img)
