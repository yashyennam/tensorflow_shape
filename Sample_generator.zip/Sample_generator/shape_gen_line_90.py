import cv2
import numpy as np
import random 

x = 12
y = 500

t_start = 2
t_end = 8

colour_s = 0
colour_e = 255

height = 512
width = 512

for num in range(0 , 4000):
    # img1 = np.ones((512, 512, 3))
    image = np.zeros([height, width, 3], dtype=np.uint8)
    
##    lineimg = cv2.line(image,
##                       (random.randint(x, y),random.randint(x, y)),
##                           (random.randint(x, y), random.randint(x, y)),
##                           (random.randint(colour_s, colour_e),
##                            random.randint(colour_s, colour_e),
##                            random.randint(colour_s, colour_e)),
##                           random.randint(t_start, t_end))
    constant = random.randint(x, y)
    image = cv2.line(image, (constant, random.randint(x, y)), (constant, random.randint(x, y)), (random.randint(x, y),random.randint(x, y), random.randint(x, y)), 3) 

    cv2.imwrite(r'/home/yash/Desktop/KhashCapitals/Interview-master/Images/line_90/line_{}.jpg'.format(num), image)

# cv2.waitKey(0)
# cv2.destroyWindow('Yash')
